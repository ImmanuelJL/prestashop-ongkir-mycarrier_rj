# Prestashop Module untuk biaya pengiriman menggunakan RAJAONGKIR

Silahkan cek http://immanueljl.blogspot.co.id untuk informasi lebih lanjut

## NOTE:
1. Module ini tidak berafiliasi dengan RAJAONGKIR maupun Prestashop
2. Use at your own RISK! Dengan menggunakan modul ini, maka pengguna tidak dapat menuntut pengembang karena kesalahan/kerugian yang ditimbulkan
3. BOLEH DIPAKAI UNTUK KEPERLUAN APAPUN TANPA MERUBAH COPYRIGHT NOTICE
